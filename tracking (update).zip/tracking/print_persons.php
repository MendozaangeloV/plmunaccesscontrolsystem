<?php
include 'db_connect.php';

$ids = $_POST['ids'] ?? [];
$id_list = implode(",", array_map('intval', $ids));
$persons = $conn->query("SELECT *, concat(lastname,', ',firstname,' ',middlename) as name, 
        concat(address,', ',street,', ',baranggay,', ',city,', ',state,', ',zip_code) as caddress 
        FROM persons WHERE id IN ($id_list)");
?>
<!DOCTYPE html>
<html>
<head>
    <title>PLMun Student IDs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style type="text/css">
        :root {
            --plmun-dark-green: #006400;
            --plmun-light-green: #228B22;
            --plmun-gold: #D4AF37;
        }
        
        body {
            background-color: #f0f0f0;
            padding: 20px;
        }
        
        .id-card {
            width: 100%;
            max-width: 380px;
            border: 4px solid var(--plmun-dark-green);
            border-radius: 12px;
            padding: 25px;
            background: white;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin: 20px auto;
            page-break-after: always;
            position: relative;
        }
        
        .id-header {
            text-align: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid var(--plmun-gold);
        }
        
        .school-logo {
            height: 60px;
            margin-bottom: 10px;
        }
        
        .school-name {
            font-size: 18px;
            font-weight: 700;
            color: var(--plmun-dark-green);
            margin-bottom: 5px;
        }
        
        .student-photo {
            width: 120px;
            height: 120px;
            border: 3px solid var(--plmun-gold);
            border-radius: 50%;
            margin: 15px auto;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .student-name {
            font-size: 20px;
            font-weight: 600;
            text-align: center;
            margin: 10px 0 5px;
        }
        
        .student-id {
            font-size: 16px;
            text-align: center;
            color: var(--plmun-dark-green);
            font-weight: 500;
        }
        
        .id-qr-container {
            text-align: center;
            margin: 20px 0;
            min-height: 180px; /* Fixed height to prevent overlap */
        }
        
        .qr-code {
            width: 150px;
            height: 150px;
            margin: 0 auto;
            border: 1px solid #eee;
            padding: 5px;
            background: white;
            display: block; /* Ensures proper rendering */
        }
        
        .student-details {
            margin: 15px 0;
            font-size: 14px;
        }
        
        .detail-row {
            display: flex;
            margin-bottom: 8px;
        }
        
        .detail-label {
            font-weight: 600;
            color: var(--plmun-dark-green);
            width: 100px;
        }
        
        .id-footer {
            text-align: center;
            font-size: 11px;
            color: #666;
            margin-top: 15px;
            padding-top: 10px;
            border-top: 1px solid #eee;
        }
        
        @media print {
            body {
                background: white !important;
                padding: 0 !important;
            }
            .id-card {
                box-shadow: none;
                margin: 0 auto;
                border-width: 3px;
            }
            .id-qr-container {
                page-break-inside: avoid;
            }
        }
    </style>
</head>
<body>
    <?php while($person = $persons->fetch_assoc()): ?>
        <div class="id-card" id="card-<?php echo $person['id'] ?>">
            <div class="id-header">
                <div class="school-logo">
                    <svg width="100%" height="100%" viewBox="0 0 300 60" xmlns="http://www.w3.org/2000/svg">
                        <text x="0" y="25" font-family="Arial" font-size="20" font-weight="bold" fill="#006400">PAMANTASAN NG LUNGSOD NG</text>
                        <text x="0" y="50" font-family="Arial" font-size="20" font-weight="bold" fill="#228B22">MUNTINLUPA</text>
                    </svg>
                </div>
                <div class="school-name">Pamantasan ng Lungsod ng Muntinlupa</div>
                <div style="font-size: 14px;">OFFICIAL STUDENT ID</div>
            </div>

            <div class="student-photo">
                <i class="fas fa-user-graduate" style="font-size: 48px; color: #006400;"></i>
            </div>

            <div class="student-name"><?php echo htmlspecialchars($person['name']) ?></div>
            <div class="student-id">ID: <?php echo htmlspecialchars($person['tracking_id']) ?></div>

            <div class="student-details">
                <div class="detail-row">
                    <div class="detail-label">Course:</div>
                    <div class="detail-value">BS Computer Science</div>
                </div>
                <div class="detail-row">
                    <div class="detail-label">Year Level:</div>
                    <div class="detail-value">3rd Year</div>
                </div>
                <div class="detail-row">
                    <div class="detail-label">Address:</div>
                    <div class="detail-value"><?php echo htmlspecialchars($person['caddress']) ?></div>
                </div>
            </div>

            <div class="id-qr-container">
                <div id="qr-<?php echo $person['id'] ?>" class="qr-code"></div>
                <div style="font-size: 12px; margin-top: 5px; color: #006400;">
                    <i class="fas fa-qrcode"></i> SCAN TO VERIFY
                </div>
            </div>

            <div class="id-footer">
                <div>Valid until: <?php echo date('M d, Y', strtotime('+1 year')) ?></div>
                <div style="margin-top: 5px;">© <?php echo date('Y') ?> PLMun. All rights reserved.</div>
            </div>
        </div>
    <?php endwhile; ?>

    <!-- Using more reliable QR library with fallback -->
    <script src="https://cdn.jsdelivr.net/npm/qr-code-styling@1.5.0/lib/qr-code-styling.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.min.js"></script>
    
    <script>
    // Wait for all elements to be loaded
    document.addEventListener('DOMContentLoaded', function() {
        // Generate QR codes for each student
        <?php 
        // Reset pointer to beginning
        $persons->data_seek(0); 
        while($person = $persons->fetch_assoc()): 
        ?>
            try {
                // Try using the modern QR library first
                const qrCode_<?php echo $person['id'] ?> = new QRCodeStyling({
                    width: 150,
                    height: 150,
                    data: `PLMun Student ID\nName: <?php echo addslashes($person['name']) ?>\nID: <?php echo $person['tracking_id'] ?>\nValid Until: <?php echo date('M d, Y', strtotime('+1 year')) ?>`,
                    dotsOptions: {
                        color: "#006400",
                        type: "rounded"
                    },
                    backgroundOptions: {
                        color: "#ffffff"
                    }
                });
                qrCode_<?php echo $person['id'] ?>.append(document.getElementById('qr-<?php echo $person['id'] ?>'));
            } catch (e) {
                console.log("Using fallback QR generator");
                // Fallback to basic QR generator
                const qr = qrcode(0, 'L');
                qr.addData(`PLMun Student ID\nName: <?php echo addslashes($person['name']) ?>\nID: <?php echo $person['tracking_id'] ?>\nValid Until: <?php echo date('M d, Y', strtotime('+1 year')) ?>`);
                qr.make();
                document.getElementById('qr-<?php echo $person['id'] ?>').innerHTML = qr.createImgTag(4, 0);
            }
        <?php endwhile; ?>

        // Print after all QR codes are generated
        setTimeout(() => {
            window.print();
            setTimeout(() => window.close(), 500);
        }, 1500); // Increased delay to ensure all QR codes render
    });

    // Fallback in case DOMContentLoaded doesn't fire
    setTimeout(() => {
        if (!document.querySelector('.qr-code canvas, .qr-code img')) {
            console.log("Manual QR generation fallback");
            <?php 
            $persons->data_seek(0); 
            while($person = $persons->fetch_assoc()): 
            ?>
                const qr = qrcode(0, 'L');
                qr.addData(`PLMun Student ID\nName: <?php echo addslashes($person['name']) ?>\nID: <?php echo $person['tracking_id'] ?>\nValid Until: <?php echo date('M d, Y', strtotime('+1 year')) ?>`);
                qr.make();
                document.getElementById('qr-<?php echo $person['id'] ?>').innerHTML = qr.createImgTag(4, 0);
            <?php endwhile; ?>
            
            setTimeout(() => {
                window.print();
                setTimeout(() => window.close(), 500);
            }, 1000);
        }
    }, 3000); // Final fallback after 3 seconds
    </script>
</body>
</html>