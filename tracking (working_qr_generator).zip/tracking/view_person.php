<?php
include 'db_connect.php';

$id = $_GET['id'] ?? 0;
$person = $conn->query("SELECT *, concat(lastname,', ',firstname,' ',middlename) as name, 
        concat(address,', ',street,', ',baranggay,', ',city,', ',state,', ',zip_code) as caddress 
        FROM persons WHERE id = $id")->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title>PLMun Student ID</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style type="text/css">
        :root {
            --plmun-dark-green: #006400;
            --plmun-light-green: #228B22;
            --plmun-gold: #D4AF37;
        }
        
        body {
            background-color: #f0f0f0;
            padding: 30px;
        }
        
        .student-id-card {
            width: 100%;
            max-width: 380px;
            border: 4px solid var(--plmun-dark-green);
            border-radius: 12px;
            padding: 25px;
            background: white;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            margin: 0 auto;
            position: relative;
            overflow: hidden;
        }
        
        .student-id-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 8px;
            background: linear-gradient(90deg, var(--plmun-dark-green), var(--plmun-light-green));
        }
        
        .id-header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--plmun-gold);
        }
        
        .school-logo {
            height: 70px;
            margin-bottom: 10px;
        }
        
        .student-photo {
            width: 120px;
            height: 120px;
            border: 3px solid var(--plmun-gold);
            border-radius: 50%;
            margin: 15px auto;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }
        
        .student-name {
            font-size: 20px;
            font-weight: 600;
            text-align: center;
            margin: 15px 0 5px;
        }
        
        .student-id {
            font-size: 16px;
            text-align: center;
            color: var(--plmun-dark-green);
            font-weight: 500;
        }
        
        .id-qr-container {
            text-align: center;
            margin: 20px 0;
            min-height: 180px;
        }
        
        #qrCodeContainer {
            width: 150px;
            height: 150px;
            margin: 0 auto;
            display: block;
        }
        
        .student-details {
            margin: 20px 0;
            font-size: 14px;
        }
        
        .detail-row {
            display: flex;
            margin-bottom: 8px;
        }
        
        .detail-label {
            font-weight: 600;
            color: var(--plmun-dark-green);
            width: 100px;
        }
        
        .id-footer {
            text-align: center;
            font-size: 11px;
            color: #666;
            margin-top: 15px;
            padding-top: 10px;
            border-top: 1px solid #eee;
        }
        
        .access-history {
            margin-top: 30px;
        }
        
        .history-table th {
            background-color: var(--plmun-dark-green);
            color: white;
        }
        
        .btn-print {
            background-color: var(--plmun-dark-green);
            border-color: var(--plmun-dark-green);
        }
        
        .btn-print:hover {
            background-color: var(--plmun-light-green);
            border-color: var(--plmun-light-green);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-4">
                <div class="student-id-card" id="toPrint">
                    <div class="id-header">
                        <div class="school-logo">
                            <svg width="100%" height="100%" viewBox="0 0 300 70" xmlns="http://www.w3.org/2000/svg">
                                <text x="0" y="25" font-family="Arial" font-size="20" font-weight="bold" fill="#006400">PAMANTASAN NG LUNGSOD NG</text>
                                <text x="0" y="50" font-family="Arial" font-size="20" font-weight="bold" fill="#228B22">MUNTINLUPA</text>
                            </svg>
                        </div>
                        <div style="font-size: 18px; font-weight: 700; color: #006400;">Pamantasan ng Lungsod ng Muntinlupa</div>
                        <div style="font-size: 14px;">OFFICIAL STUDENT ID</div>
                    </div>

                    <div class="student-photo">
                        <i class="fas fa-user-graduate" style="font-size: 48px; color: #006400;"></i>
                    </div>

                    <div class="student-name"><?php echo htmlspecialchars($person['name']) ?></div>
                    <div class="student-id">ID: <?php echo htmlspecialchars($person['tracking_id']) ?></div>

                    <div class="student-details">
                        <div class="detail-row">
                            <div class="detail-label">Course:</div>
                            <div class="detail-value">BS Computer Science</div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Year Level:</div>
                            <div class="detail-value">3rd Year</div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Address:</div>
                            <div class="detail-value"><?php echo htmlspecialchars($person['caddress']) ?></div>
                        </div>
                    </div>

                    <div class="id-qr-container">
                        <div id="qrCodeContainer"></div>
                        <div style="font-size: 12px; margin-top: 8px; color: #006400;">
                            <i class="fas fa-qrcode"></i> SCAN TO VERIFY IDENTITY
                        </div>
                    </div>

                    <div class="id-footer">
                        <div>Valid until: <?php echo date('M d, Y', strtotime('+1 year')) ?></div>
                        <div style="margin-top: 5px;">© <?php echo date('Y') ?> PLMun. All rights reserved.</div>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="access-history card shadow">
                    <div class="card-header bg-dark text-white">
                        <h5 class="mb-0"><i class="fas fa-history"></i> Campus Access History</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table history-table">
                                <thead>
                                    <tr>
                                        <th class="text-center">#</th>
                                        <th>Date & Time</th>
                                        <th>Building</th>
                                        <th>Room</th>
                                        <th class="text-right">Temp</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $i = 1;
                                    $tracks = $conn->query("SELECT t.*, e.address, e.name as ename 
                                                          FROM person_tracks t 
                                                          INNER JOIN establishments e ON e.id = t.establishment_id 
                                                          WHERE t.person_id = '$id' 
                                                          ORDER BY t.date_created DESC");
                                    while($row = $tracks->fetch_assoc()):
                                    ?>
                                    <tr>
                                        <td class="text-center"><?php echo $i++ ?></td>
                                        <td><?php echo date("M d, Y h:i A", strtotime($row['date_created'])) ?></td>
                                        <td><?php echo ucwords($row['ename']) ?></td>
                                        <td><?php echo $row['address'] ?></td>
                                        <td class="text-right"><?php echo $row['temperature'] ?>&#730;C</td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal-footer display mt-4">
        <div class="row justify-content-center">
            <div class="col-auto">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-times"></i> Close
                </button>
                <button class="btn btn-print text-white ml-2" type="button" id="print">
                    <i class="fas fa-print"></i> Print ID
                </button>
                <form action="index.php?page=print_persons" method="POST" style="display: inline;">
                    <input type="hidden" name="ids[]" value="<?php echo $id ?>">
                    <button type="submit" class="btn btn-success ml-2">
                        <i class="fas fa-id-card"></i> Print Full ID
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/qr-code-styling@1.5.0/lib/qr-code-styling.min.js"></script>

    <script>
    // Double ensure the QR code loads
    function generateQRCode() {
        const qrData = `PLMun STUDENT ID
Name: <?php echo addslashes($person['name']) ?>
ID: <?php echo $person['tracking_id'] ?>
Course: BS Computer Science
Year: 3rd Year
Valid Until: <?php echo date('M d, Y', strtotime('+1 year')) ?>`;
        
        const qrCode = new QRCodeStyling({
            width: 150,
            height: 150,
            data: qrData,
            margin: 10,
            dotsOptions: { color: "#006400", type: "rounded" },
            cornersSquareOptions: { type: "extra-rounded", color: "#006400" },
            cornersDotOptions: { type: "dot", color: "#006400" },
            backgroundOptions: { color: "#ffffff" }
        });
        
        // Clear container first
        document.getElementById('qrCodeContainer').innerHTML = '';
        // Append new QR code
        qrCode.append(document.getElementById('qrCodeContainer'));
        
        return qrData;
    }

    // Multiple load triggers to ensure QR code appears
    $(document).ready(function() {
        const qrData = generateQRCode();
        
        // Print button functionality
        $('#print').click(function() {
            const printContent = $('#toPrint').html();
            const printWindow = window.open('', '_blank');
            printWindow.document.write(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>PLMun Student ID</title>
                    <style>
                        body { margin: 0; padding: 20px; background: white !important; }
                        .student-id-card { 
                            border: 3px solid #006400;
                            border-radius: 12px;
                            padding: 25px;
                            width: 380px;
                            margin: 0 auto;
                            background: white;
                        }
                        #qrCodeContainer { 
                            width: 150px; 
                            height: 150px; 
                            margin: 15px auto; 
                        }
                    </style>
                </head>
                <body>
                    ${printContent}
                    <script src="https://cdn.jsdelivr.net/npm/qr-code-styling@1.5.0/lib/qr-code-styling.min.js"><\/script>
                    <script>
                        const qrCode = new QRCodeStyling({
                            width: 150,
                            height: 150,
                            data: \`${qrData}\`,
                            dotsOptions: { color: '#006400' }
                        });
                        document.getElementById('qrCodeContainer').innerHTML = '';
                        qrCode.append(document.getElementById('qrCodeContainer'));
                        setTimeout(() => { 
                            window.print(); 
                            window.close(); 
                        }, 500);
                    <\/script>
                </body>
                </html>
            `);
            printWindow.document.close();
        });
    });

    // Additional trigger when page fully loads
    window.addEventListener('load', function() {
        generateQRCode();
    });
    </script>
</body>
</html>