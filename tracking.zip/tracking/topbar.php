<?php
// This file should NOT contain session_start()
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PLMUN Access Control System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Topbar Container */
        .topbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 60px;
            background: linear-gradient(135deg, #00b050,rgb(0, 100, 17));
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            z-index: 1100;
        }
        
        /* Logo Container */
        .logo-container {
            display: flex;
            align-items: center;
            height: 100%;
            cursor: pointer; /* Add pointer cursor */
            transition: transform 0.3s; /* Add hover effect */
        }
        
        .logo-container:hover {
            transform: scale(1.02); /* Slight zoom on hover */
        }
        
        /* Logo Image */
        .logo-img {
            height: 40px;
            width: auto;
            margin-right: 15px;
        }
        
        /* System Title */
        .system-title {
            font-size: 1.2rem;
            font-weight: bold;
            line-height: 1.2;
            color: white;
        }
        
        .system-title small {
            font-size: 0.8rem;
            font-weight: normal;
            display: block;
            color: rgba(255,255,255,0.8);
        }
        
        /* Hamburger Button */
        .hamburger-btn {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            padding: 10px;
            margin-right: 15px;
            transition: transform 0.3s;
        }
        
        .hamburger-btn:hover {
            transform: scale(1.1);
        }
        
        /* User Menu */
        .user-menu {
            display: flex;
            align-items: center;
            height: 100%;
        }
        
        /* User Name */
        .user-name {
            margin-right: 15px;
            font-size: 0.9rem;
        }
        
        /* Logout Button */
        .logout-btn {
            color: white;
            background: rgba(255,255,255,0.2);
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            font-size: 0.9rem;
        }
        
        .logout-btn:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .logout-btn i {
            margin-right: 5px;
        }
    </style>
</head>
<body>
    <div class="topbar">
        <!-- Left Side: Navigation Controls -->
        <div style="display: flex; align-items: center;">
            <!-- Hamburger Menu Button -->
            <button class="hamburger-btn" id="sidebarToggle">
                <i class="fas fa-bars"></i>
            </button>
            
            <!-- Clickable Logo and System Title -->
            <a href="dashboard.php" style="display: flex; align-items: center; text-decoration: none;">
                <div class="logo-container">
                    <img src="assets/img/PLMUNLOGO.png" class="logo-img" alt="PLMUN Logo">
                    <div class="system-title">
                        Pamantasan ng Lungsod ng Muntinlupa
                        <small>Access Control System</small>
                    </div>
                </div>
            </a>
        </div>
        
        <!-- Right Side: User Menu -->
        <div class="user-menu">
            <span class="user-name"><?php echo htmlspecialchars($_SESSION['login_name'] ?? 'Guest'); ?></span>
            <a href="ajax.php?action=logout" class="logout-btn">
                <i class="fas fa-power-off"></i> Logout
            </a>
        </div>
    </div>

    <script>
    // Sidebar Toggle Functionality
    document.addEventListener('DOMContentLoaded', function() {
        const sidebarToggle = document.getElementById('sidebarToggle');
        
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function(e) {
                e.preventDefault();
                const sidebar = document.getElementById('sidebar');
                const overlay = document.querySelector('.overlay') || createOverlay();
                
                sidebar.classList.toggle('active');
                overlay.style.display = sidebar.classList.contains('active') ? 'block' : 'none';
            });
        }
        
        function createOverlay() {
            const overlay = document.createElement('div');
            overlay.className = 'overlay';
            overlay.style.cssText = `
                position: fixed;
                top: 60px;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0,0,0,0.5);
                z-index: 999;
                display: none;
            `;
            overlay.addEventListener('click', function() {
                document.getElementById('sidebar').classList.remove('active');
                this.style.display = 'none';
            });
            document.body.appendChild(overlay);
            return overlay;
        }
    });
    </script>
</body>
</html>