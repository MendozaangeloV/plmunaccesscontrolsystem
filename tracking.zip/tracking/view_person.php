<?php
include 'db_connect.php';

$id = $_GET['id'] ?? 0;
$person = $conn->query("SELECT *, concat(lastname,', ',firstname,' ',middlename) as name, 
        concat(address,', ',street,', ',baranggay,', ',city,', ',state,', ',zip_code) as caddress 
        FROM persons WHERE id = $id")->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title>PLMun Student ID</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style type="text/css">
        :root {
            --plmun-dark-green: #006400;
            --plmun-light-green: #228B22;
            --plmun-gold: #D4AF37;
            --plmun-light: #F8F9FA;
            --plmun-dark: #212529;
        }
        
        body {
            background-color: #f0f0f0;
            padding: 30px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .student-id-card {
            width: 100%;
            max-width: 380px;
            border: 4px solid var(--plmun-dark-green);
            border-radius: 12px;
            padding: 25px;
            background: white;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            margin: 0 auto;
            position: relative;
            overflow: hidden;
        }
        
        .student-id-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 8px;
            background: linear-gradient(90deg, var(--plmun-dark-green), var(--plmun-light-green));
        }
        
        .id-header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--plmun-gold);
        }
        
        .school-logo {
            height: 70px;
            margin-bottom: 10px;
        }
        
        .school-name {
            font-size: 18px;
            font-weight: 700;
            color: var(--plmun-dark-green);
            margin-bottom: 5px;
            text-transform: uppercase;
        }
        
        .id-title {
            font-size: 14px;
            color: var(--plmun-dark);
            letter-spacing: 1px;
        }
        
        .student-photo {
            width: 120px;
            height: 120px;
            border: 3px solid var(--plmun-gold);
            border-radius: 50%;
            margin: 15px auto;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .student-photo-placeholder {
            font-size: 48px;
            color: var(--plmun-dark-green);
        }
        
        .student-name {
            font-size: 20px;
            font-weight: 600;
            text-align: center;
            margin: 15px 0 5px;
            color: var(--plmun-dark);
        }
        
        .student-id {
            font-size: 16px;
            text-align: center;
            color: var(--plmun-dark-green);
            font-weight: 500;
            margin-bottom: 15px;
        }
        
        .id-qr-container {
            text-align: center;
            margin: 20px 0;
            padding: 15px;
            background-color: rgba(0, 100, 0, 0.05);
            border-radius: 8px;
            border: 1px dashed var(--plmun-light-green);
        }
        
        #qrCanvas {
            width: 150px !important;
            height: 150px !important;
            margin: 0 auto;
            padding: 5px;
            background: white;
        }
        
        .student-details {
            margin: 20px 0;
            font-size: 14px;
        }
        
        .detail-row {
            display: flex;
            margin-bottom: 8px;
        }
        
        .detail-label {
            font-weight: 600;
            color: var(--plmun-dark-green);
            width: 100px;
        }
        
        .detail-value {
            flex: 1;
            color: var(--plmun-dark);
        }
        
        .id-footer {
            text-align: center;
            font-size: 11px;
            color: #666;
            margin-top: 15px;
            padding-top: 10px;
            border-top: 1px solid #eee;
        }
        
        .plmun-watermark {
            position: absolute;
            bottom: 20px;
            right: 20px;
            opacity: 0.1;
            font-size: 80px;
            color: var(--plmun-dark-green);
            z-index: 0;
        }
        
        @media print {
            body {
                background: white !important;
                padding: 0 !important;
            }
            .no-print {
                display: none !important;
            }
            .student-id-card {
                box-shadow: none !important;
                border-width: 3px !important;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- ID Card Column -->
            <div class="col-lg-4">
                <div class="container-fluid" id="toPrint">
                    <div class="student-id-card">
                        <div class="plmun-watermark">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        
                        <div class="id-header">
                            <div class="school-logo">
                                <!-- PLMun Logo Placeholder -->
                                <svg width="100%" height="100%" viewBox="0 0 300 70" xmlns="http://www.w3.org/2000/svg">
                                    <text x="0" y="35" font-family="Arial" font-size="24" font-weight="bold" fill="#006400">PAMANTASAN NG LUNGSOD NG</text>
                                    <text x="0" y="60" font-family="Arial" font-size="24" font-weight="bold" fill="#228B22">MUNTINLUPA</text>
                                </svg>
                            </div>
                            <div class="school-name">Pamantasan ng Lungsod ng Muntinlupa</div>
                            <div class="id-title">OFFICIAL STUDENT IDENTIFICATION CARD</div>
                        </div>

                        <div class="student-photo">
                            <div class="student-photo-placeholder">
                                <i class="fas fa-user-graduate"></i>
                            </div>
                        </div>

                        <div class="student-name"><?php echo htmlspecialchars($person['name']) ?></div>
                        <div class="student-id">ID: <?php echo htmlspecialchars($person['tracking_id']) ?></div>

                        <div class="student-details">
                            <div class="detail-row">
                                <div class="detail-label">Course:</div>
                                <div class="detail-value">Bachelor of Science in Computer Science</div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Year Level:</div>
                                <div class="detail-value">3rd Year</div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Address:</div>
                                <div class="detail-value"><?php echo htmlspecialchars($person['caddress']) ?></div>
                            </div>
                        </div>

                        <div class="id-qr-container">
                            <canvas id="qrCanvas" width="150" height="150"></canvas>
                            <div style="font-size: 12px; margin-top: 8px; color: var(--plmun-dark-green);">
                                <i class="fas fa-qrcode"></i> SCAN TO VERIFY STUDENT ID
                            </div>
                        </div>

                        <div class="id-footer">
                            <div>Valid until: <?php echo date('M d, Y', strtotime('+1 year')) ?></div>
                            <div style="margin-top: 5px;">© <?php echo date('Y') ?> PLMun. All rights reserved.</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tracking History Column -->
            <div class="col-lg-8">
                <div class="card border-0 shadow">
                    <div class="card-header bg-plmun-green text-white">
                        <h5 class="mb-0"><i class="fas fa-history"></i> Campus Access History</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="thead-dark">
                                    <tr>
                                        <th class="text-center">#</th>
                                        <th>Date & Time</th>
                                        <th>Building</th>
                                        <th>Room</th>
                                        <th class="text-right">Temp</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $i = 1;
                                    $tracks = $conn->query("SELECT t.*, e.address, e.name as ename 
                                                          FROM person_tracks t 
                                                          INNER JOIN establishments e ON e.id = t.establishment_id 
                                                          WHERE t.person_id = '$id' 
                                                          ORDER BY t.date_created DESC");
                                    while($row = $tracks->fetch_assoc()):
                                    ?>
                                    <tr>
                                        <td class="text-center"><?php echo $i++ ?></td>
                                        <td><?php echo date("M d, Y h:i A", strtotime($row['date_created'])) ?></td>
                                        <td><?php echo ucwords($row['ename']) ?></td>
                                        <td><?php echo $row['address'] ?></td>
                                        <td class="text-right"><?php echo $row['temperature'] ?>&#730;C</td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal-footer display no-print mt-4">
        <div class="row justify-content-center">
            <div class="col-auto">
                <button class="btn btn-outline-plmun-green" type="button" data-dismiss="modal">
                    <i class="fas fa-times"></i> Close
                </button>
                <button class="btn btn-plmun-green ml-2" type="button" id="print">
                    <i class="fas fa-print"></i> Print ID
                </button>
            </div>
        </div>
    </div>

    <!-- QR Code Library -->
    <script src="https://cdn.jsdelivr.net/npm/qr-code-styling@1.5.0/lib/qr-code-styling.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Format the QR code data
        const qrData = `PLMun STUDENT ID
Name: <?php echo addslashes($person['name']) ?>
Student ID: <?php echo $person['tracking_id'] ?>
Course: BS Computer Science
Year Level: 3rd Year
Valid Until: <?php echo date('M d, Y', strtotime('+1 year')) ?>
Address: <?php echo addslashes($person['caddress']) ?>`;
        
        // Configure QR code with PLMun styling
        const qrCode = new QRCodeStyling({
            width: 150,
            height: 150,
            data: qrData,
            margin: 10,
            qrOptions: {
                typeNumber: 0,
                mode: 'Byte',
                errorCorrectionLevel: 'H'
            },
            dotsOptions: {
                color: '#006400',
                type: 'rounded'
            },
            cornersSquareOptions: {
                type: 'extra-rounded',
                color: '#006400'
            },
            cornersDotOptions: {
                type: 'dot',
                color: '#006400'
            },
            backgroundOptions: {
                color: '#ffffff'
            }
        });
        
        // Append QR code to canvas
        qrCode.append(document.getElementById('qrCanvas'));
    });

    // Print Function
    document.getElementById('print').addEventListener('click', function() {
        const printWindow = window.open('', '_blank', 'width=900,height=700');
        const content = document.getElementById('toPrint').innerHTML;
        
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>PLMun Student ID</title>
                <style>
                    body { 
                        margin: 0; 
                        padding: 20px; 
                        background: white !important;
                    }
                    .student-id-card {
                        margin: 0 auto;
                    }
                </style>
            </head>
            <body>
                ${content}
                <script src="https://cdn.jsdelivr.net/npm/qr-code-styling@1.5.0/lib/qr-code-styling.min.js"><\/script>
                <script>
                    const qrData = \`PLMun STUDENT ID
Name: <?php echo addslashes($person['name']) ?>
Student ID: <?php echo $person['tracking_id'] ?>
Course: BS Computer Science
Year Level: 3rd Year
Valid Until: <?php echo date('M d, Y', strtotime('+1 year')) ?>
Address: <?php echo addslashes($person['caddress']) ?>\`;
                    
                    const qrCode = new QRCodeStyling({
                        width: 150,
                        height: 150,
                        data: qrData,
                        dotsOptions: { color: '#006400' }
                    });
                    qrCode.append(document.getElementById('qrCanvas'));
                    
                    window.onload = function() {
                        setTimeout(function() {
                            window.print();
                            setTimeout(function() {
                                window.close();
                            }, 300);
                        }, 500);
                    };
                <\/script>
            </body>
            </html>
        `);
        
        printWindow.document.close();
    });

    // Add PLMun color to Bootstrap
    const style = document.createElement('style');
    style.innerHTML = `
        .bg-plmun-green { background-color: #006400 !important; }
        .btn-plmun-green { 
            background-color: #006400 !important; 
            color: white !important;
            border-color: #005300 !important;
        }
        .btn-outline-plmun-green {
            color: #006400 !important;
            border-color: #006400 !important;
        }
        .btn-outline-plmun-green:hover {
            background-color: #006400 !important;
            color: white !important;
        }
    `;
    document.head.appendChild(style);
    </script>
</body>
</html>