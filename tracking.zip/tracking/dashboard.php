<?php
// Start session at the very beginning
session_start();

// Redirect to login if not authenticated
if (!isset($_SESSION['login_id'])) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | PLMUN Access Control Systeem</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <style>
        body {
            padding-top: 60px; /* Match topbar height */
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .dashboard-container {
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .dashboard-header {
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid #dee2e6;
        }
        
        .stat-card {
            text-align: center;
            padding: 25px 15px;
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-value {
            font-size: 2.5rem;
            font-weight: bold;
            color: #2c3e50;
        }
        
        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .recent-activity {
            margin-top: 30px;
        }
    </style>
</head>
<body>
    <!-- Include Topbar -->
    <?php include 'topbar.php'; ?>
    
    <!-- Include Navbar -->
    <?php include 'navbar.php'; ?>
    
    <!-- Main Dashboard Content -->
    <main class="dashboard-container">
        <div class="dashboard-header">
            <h2>Welcome, <?php echo htmlspecialchars($_SESSION['login_name']); ?></h2>
            <p class="text-muted">System Overview and Quick Access</p>
        </div>

        <?php include 'db_connect.php' ?>
<style>
   span.float-right.summary_icon {
    font-size: 3rem;
    position: absolute;
    right: 1rem;
    color: #ffffff96;
}
</style>

<div class="containe-fluid">

	<div class="row mt-3 ml-3 mr-3">
			<div class="col-lg-12">
    			<div class="card">
    				<div class="card-body">
    				<?php echo "Welcome back to PLMUN <br> Please Scan your QR Code "  ?>
    					<hr>	

                        <div class="row">
                            <div class="col-lg-8 offset-2">
                                <div class="container-fluid">
                                <form action="" id="manage-records">
                                    <input type="hidden" name="id" value="<?php echo isset($id) ? $id :'' ?>">
                                    <div class="form-group">
                                        <label for="" class="control-label">Tracking ID</label>
                                        <input type="number" class="form-control" id="tracking_id" name="tracking_id"  value="<?php echo isset($tracking_id) ? $tracking_id :'' ?>" required autocomplete="off">
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <button class="btn btn-sm btn-primary btn-sm col-sm-2 btn-block float-right" type="button" id="check">Check</button>
                                        </div>
                                    </div>
                                    <div id="details" <?php echo isset($id) ? "style='display:block'" : 'style="display:none"' ?>>
                                        <p><b>Name: <span id="name"><?php echo isset($id) ? ucwords($name) : '' ?></span></b></p>
                                        <p><b>Address: <span id="address"><?php echo isset($id) ? $caddress : '' ?></span></b></p>
                                        <input type="hidden" name="person_id" value="<?php echo isset($person_id) ? $person_id : '' ?>">
                                        <div class="form-group">
                                            <label for="" class="control-label">Temperature</label>
                                            <input type="text" class="form-control" name="temperature"  value="<?php echo isset($temperature) ? $temperature :'' ?>" required>
                                        </div>
                                        <?php if($_SESSION['login_type'] == 1): ?>
                                        <div class="form-group">
                                            <label for="" class="control-label">Establishment</label>
                                            <select name="establishment_id" id="" class="custom-select select2">
                                                <option value=""></option>
                                        <?php 
                                            $establishment = $conn->query("SELECT * FROM establishments order by name asc");
                                            while($row= $establishment->fetch_assoc()):
                                        ?>
                                                <option value="<?php echo $row['id'] ?>" <?php echo isset($establishment_id) && $row['id'] == $establishment_id ? 'selected' : '' ?>><?php echo $row['name'] ?></option>
                                        <?php endwhile; ?>
                                            </select>
                                        </div>
                                        <?php else: ?>
                                        <input type="hidden" name="establishment_id" value="<?php echo isset($establishment_id) ? $establishment_id : $_SESSION['login_establishment_id'] ?>">
                                        <?php endif; ?>
                                <hr>
                                <div class="row">
                                    <div class="col-md-12">
                                    <button class="btn btn-sm btn-secondary btn-block col-sm-2 float-right" type="button" onlclick='reset_form()'>Cancel</button>
                                        <button class="btn btn-sm btn-primary btn-block col-sm-2 float-right mt-0 mr-2">Save</button>
                                    </div>
                                    
                                </div>
                                </div>
                                </form>
                            </div>
                            </div>
                        </div>      			
    				</div>
    		      </div>
                </div>
	</div>
    </main>
</div>





<script>
	$('#manage-records').submit(function(e){
        e.preventDefault()
        start_load()
        $.ajax({
            url:'ajax.php?action=save_track',
            data: new FormData($(this)[0]),
            cache: false,
            contentType: false,
            processData: false,
            method: 'POST',
            type: 'POST',
            success:function(resp){
                resp=JSON.parse(resp)
                if(resp.status==1){
                    alert_toast("Data successfully saved",'success')
                    setTimeout(function(){
                        location.reload()
                    },800)

                }
                
            }
        })
    })
    $('#tracking_id').on('keypress',function(e){
        if(e.which == 13){
            get_person()
        }
    })
    $('#check').on('click',function(e){
            get_person()
    })
    function get_person(){
            start_load()
        $.ajax({
                url:'ajax.php?action=get_pdetails',
                method:"POST",
                data:{tracking_id : $('#tracking_id').val()},
                success:function(resp){
                    if(resp){
                        resp = JSON.parse(resp)
                        if(resp.status == 1){
                            $('#name').html(resp.name)
                            $('#address').html(resp.address)
                            $('[name="person_id"]').val(resp.id)
                            $('#details').show()
                            end_load()

                        }else if(resp.status == 2){
                            alert_toast("Unknow tracking id.",'danger');
                            end_load();
                        }
                    }
                }
            })
    }
</script>

    

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JavaScript -->
    <script>
    // Ensure sidebar is closed when dashboard loads
    document.addEventListener('DOMContentLoaded', function() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.querySelector('.overlay');
        
        if (sidebar) {
            sidebar.classList.remove('active');
        }
        
        if (overlay) {
            overlay.style.display = 'none';
        }
        
        // Add any dashboard-specific JavaScript here
    });
    </script>
</body>
</html>