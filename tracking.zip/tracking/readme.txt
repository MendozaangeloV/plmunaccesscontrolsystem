

Download the zip file/ download winrar

Extract the file and copy "tracking" folder

Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

Open PHPMyAdmin (http://localhost/phpmyadmin)

Create a database with name tracking_db

Import btracking_db.sql file(given inside the zip package in SQL file folder)

Run the script http://localhost/tracking


**LOGIN DETAILS** 

Admin
user: admin
pass: admin123

